package com.kd.util;
/**
 * 获取session
 */

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
@Component
public class SessionUtil {
	@Autowired
	private SessionFactory sessionFactory;
	/**
	 * 
	 * @return  获取session
	 */
	public  Session getSession(){
	    Session session = sessionFactory.openSession();
	    return session;
	}
	public  Session getCurrentSession(){
	    Session session = sessionFactory.getCurrentSession();
	    return session;
	}
}
