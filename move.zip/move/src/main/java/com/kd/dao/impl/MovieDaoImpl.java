package com.kd.dao.impl;

import com.kd.dao.IMovieDao;
import com.kd.pojo.MoveName;
import com.kd.util.SessionUtil;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Order;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;

public class MovieDaoImpl implements IMovieDao {
    @Autowired
    private SessionUtil sessionUtil;
    @Override
    public List<MoveName> selectMovieNameTop() {
        Session session=sessionUtil.getCurrentSession();
        Criteria criteria=session.createCriteria(MoveName.class);
        //按价格升序排列
        criteria.addOrder(Order.asc("price"));
        List<MoveName>list=criteria.list();
        return list;
    }
}
