package com.kd.service;

import com.kd.pojo.MoveName;

import java.util.List;

public interface IMovieService {
    /**
     * 获取过根据价格升序排列后的电影名称
     * @return
     */
    public List<MoveName> findMoveNameTop();
}
