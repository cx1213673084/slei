package com.kd.service.impl;

import com.kd.dao.IMovieDao;
import com.kd.pojo.MoveName;
import com.kd.service.IMovieService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class MovieServiceImpl implements IMovieService {
    @Autowired
    private IMovieDao dao;
    @Override
    public List<MoveName> findMoveNameTop() {
        return null;
    }
}
