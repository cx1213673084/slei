package com.kd.pojo;

import javax.persistence.*;

@Entity
@Table(name = "tb_name")
public class MoveName {
    @Id
    @GeneratedValue(strategy= GenerationType.AUTO)
    private int id;
    @Column(name = "movename",unique = true,length = 12)
    private String movename;
    @Column(name = "price",length = 12)
    private int price;
    public  MoveName(){

    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getMovename() {
        return movename;
    }

    public void setMovename(String movename) {
        this.movename = movename;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    @Override
    public String toString() {
        return "MoveName{" +
                "id=" + id +
                ", movename='" + movename + '\'' +
                ", price=" + price +
                '}';
    }
}
